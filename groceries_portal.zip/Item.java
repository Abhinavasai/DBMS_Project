
import java.io.*;
import java.util.*;

public class Item
{
int id;
String name;
int price;
String cat;
int stock;


Item(int id,String name,int price,String cat,int stock)
{
    this.id=id;
    this.name=name;
    this.price=price;
    this.cat=cat;
    this.stock=stock;
}



}